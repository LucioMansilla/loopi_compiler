#ifndef EVAL_H
#define EVAL_H
#include "ast.h"

void eval(ASTNode *node);

#endif