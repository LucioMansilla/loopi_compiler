#ifndef SEMANTIC_H
#define SEMANTIC_H
#include "../structures/ast.h"
#include "../error-handling/errors.h"

void check_types(ASTNode* node);

#endif